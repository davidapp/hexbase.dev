# Magic numbers

PNG: 89 50 4E 47 · ZIP: PK.. · ELF: 7F 45 4C 46
