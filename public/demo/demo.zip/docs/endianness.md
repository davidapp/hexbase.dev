# Endianness

The names come from Gulliver's Travels (Danny Cohen, 1980).
