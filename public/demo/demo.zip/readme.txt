hexbase.dev demo archive
========================

Every file in this archive exists to be taken apart.
Open it in the hex inspector and follow the offsets.

Fun fact: this ZIP's real index (the central directory)
lives at the END of the file, not the beginning.
